import tkinter as tk
from tkinter import messagebox

def calculate_result():
    try:
        roll_no = entry_roll.get().strip()
        name = entry_name.get().strip()

        if roll_no == "" or name == "":
            messagebox.showerror("Error", "Roll Number and Name are required")
            return

        subjects = {
            "Mathematics": int(entry_math.get()),
            "Physics": int(entry_phy.get()),
            "Chemistry": int(entry_chem.get()),
            "Computer": int(entry_cs.get()),
            "English": int(entry_eng.get())
        }

        for subject, marks in subjects.items():
            if marks < 0 or marks > 100:
                messagebox.showerror("Error", f"Invalid marks in {subject}")
                return

        total = sum(subjects.values())
        percentage = total / 5

        if percentage >= 85:
            grade = "A"
        elif percentage >= 70:
            grade = "B"
        elif percentage >= 50:
            grade = "C"
        else:
            grade = "Fail"

        output = f"Roll No: {roll_no}\nName: {name}\n\n"
        for sub, marks in subjects.items():
            output += f"{sub}: {marks}\n"

        output += f"\nTotal Marks: {total}/500"
        output += f"\nPercentage: {percentage:.2f}%"
        output += f"\nGrade: {grade}"

        result_label.config(text=output)

    except ValueError:
        messagebox.showerror("Error", "Please enter valid numeric marks")


# ---------------- UI DESIGN ---------------- #

root = tk.Tk()
root.title("Student Result Management System")
root.geometry("450x600")
root.resizable(False, False)

title = tk.Label(root, text="Student Result Calculator", font=("Arial", 16, "bold"))
title.pack(pady=10)

frame = tk.Frame(root)
frame.pack()

# Roll & Name
tk.Label(frame, text="Roll Number").grid(row=0, column=0, padx=10, pady=5, sticky="w")
entry_roll = tk.Entry(frame)
entry_roll.grid(row=0, column=1)

tk.Label(frame, text="Student Name").grid(row=1, column=0, padx=10, pady=5, sticky="w")
entry_name = tk.Entry(frame)
entry_name.grid(row=1, column=1)

# Subject Marks
tk.Label(frame, text="Mathematics").grid(row=2, column=0, sticky="w")
entry_math = tk.Entry(frame)
entry_math.grid(row=2, column=1)

tk.Label(frame, text="Physics").grid(row=3, column=0, sticky="w")
entry_phy = tk.Entry(frame)
entry_phy.grid(row=3, column=1)

tk.Label(frame, text="Chemistry").grid(row=4, column=0, sticky="w")
entry_chem = tk.Entry(frame)
entry_chem.grid(row=4, column=1)

tk.Label(frame, text="Computer").grid(row=5, column=0, sticky="w")
entry_cs = tk.Entry(frame)
entry_cs.grid(row=5, column=1)

tk.Label(frame, text="English").grid(row=6, column=0, sticky="w")
entry_eng = tk.Entry(frame)
entry_eng.grid(row=6, column=1)

# Button
tk.Button(root, text="Calculate Result", command=calculate_result,
          bg="#4CAF50", fg="white", width=20).pack(pady=15)

# Result Display
result_label = tk.Label(root, text="", justify="left", font=("Arial", 10), relief="solid", padx=10, pady=10)
result_label.pack(padx=10, fill="both")

root.mainloop()
